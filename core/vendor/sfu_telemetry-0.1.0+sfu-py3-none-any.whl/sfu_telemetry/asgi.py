"""Pure-ASGI server middleware (FastAPI / Starlette).

* continues an incoming W3C ``traceparent`` or starts a new trace,
* names the span ``METHOD /route/{template}`` once routing has resolved,
* returns ``X-Request-ID: <trace_id>`` so a user-reported id finds the trace,
* emits one ``http.request`` log line with the route TEMPLATE, status and
  duration. No raw path, query string or client address is recorded.

No dependency on Starlette at import time, so it costs nothing to non-ASGI users.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Awaitable, Callable, Iterable, MutableMapping
from typing import Any

from opentelemetry import context, propagate, trace
from opentelemetry.trace import SpanKind, Status, StatusCode

from sfu_telemetry.tracing import meter, tracer

Scope = MutableMapping[str, Any]
Message = MutableMapping[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]
ASGIApp = Callable[[Scope, Receive, Send], Awaitable[None]]

access_log = logging.getLogger("sfu_telemetry.access")


def _route_template(scope: Scope) -> str | None:
    route = scope.get("route")
    for attr in ("path_format", "path"):
        value = getattr(route, attr, None)
        if isinstance(value, str):
            return value
    return None


class TelemetryMiddleware:
    def __init__(self, app: ASGIApp, *, excluded_paths: Iterable[str] = ("/health",)) -> None:
        self.app = app
        self.excluded = frozenset(excluded_paths)
        self._duration = meter().create_histogram(
            "http.server.request.duration", unit="s", description="HTTP server request duration"
        )

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http" or scope.get("path") in self.excluded:
            await self.app(scope, receive, send)
            return

        carrier = {k.decode("latin-1"): v.decode("latin-1") for k, v in scope.get("headers", [])}
        parent = propagate.extract(carrier)
        method = str(scope.get("method", "GET"))
        start = time.perf_counter()
        status_code = 500
        span = tracer().start_span(
            method,
            context=parent,
            kind=SpanKind.SERVER,
            attributes={"http.request.method": method},
        )
        token = context.attach(trace.set_span_in_context(span, parent))
        span_ctx = span.get_span_context()
        # No X-Request-ID without a real trace (no SDK provider installed).
        trace_id = format(span_ctx.trace_id, "032x") if span_ctx.is_valid else None

        async def send_wrapper(message: Message) -> None:
            nonlocal status_code
            if message.get("type") == "http.response.start":
                status_code = int(message.get("status", 500))
                headers = list(message.get("headers", []))
                if trace_id and not any(k.lower() == b"x-request-id" for k, _ in headers):
                    headers.append((b"x-request-id", trace_id.encode()))
                message["headers"] = headers
            await send(message)

        error_type: str | None = None
        try:
            await self.app(scope, receive, send_wrapper)
        except BaseException as exc:
            error_type = type(exc).__name__
            raise
        finally:
            route = _route_template(scope)
            if route:
                span.update_name(f"{method} {route}")
                span.set_attribute("http.route", route)
            span.set_attribute("http.response.status_code", status_code)
            if error_type:
                span.set_attribute("error.type", error_type)
            if error_type or status_code >= 500:
                span.set_status(Status(StatusCode.ERROR, error_type or str(status_code)))
            duration = time.perf_counter() - start
            attrs: dict[str, str | int] = {
                "http.request.method": method,
                "http.response.status_code": status_code,
            }
            if route:
                attrs["http.route"] = route
            self._duration.record(duration, attrs)
            access_log.info(
                "http.request",
                extra={**attrs, "duration_ms": round(duration * 1000, 1)},
            )
            span.end()
            context.detach(token)
