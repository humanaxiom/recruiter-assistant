"""httpx event hooks that propagate W3C trace context to downstream services.

Use with any client you construct::

    httpx.Client(..., event_hooks=sync_event_hooks())
    httpx.AsyncClient(..., event_hooks=async_event_hooks())

Hooks only add ``traceparent`` (and ``tracestate`` when present); they never
read or log the request URL or body.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import TYPE_CHECKING, Any

from opentelemetry import propagate

if TYPE_CHECKING:
    import httpx


def inject_trace_headers(request: httpx.Request) -> None:
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    for key, value in carrier.items():
        request.headers[key] = value


async def ainject_trace_headers(request: httpx.Request) -> None:
    inject_trace_headers(request)


def sync_event_hooks() -> dict[str, list[Callable[..., Any]]]:
    return {"request": [inject_trace_headers]}


def async_event_hooks() -> dict[str, list[Callable[..., Awaitable[Any]]]]:
    return {"request": [ainject_trace_headers]}
