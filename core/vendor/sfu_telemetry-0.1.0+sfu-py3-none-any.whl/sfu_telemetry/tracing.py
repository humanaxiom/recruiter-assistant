"""Tracer and meter providers with STC resource attributes."""

from __future__ import annotations

from opentelemetry import metrics, trace
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import (
    ConsoleMetricExporter,
    MetricReader,
    PeriodicExportingMetricReader,
)
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace import SpanProcessor, TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, ConsoleSpanExporter

from sfu_telemetry.config import TelemetryConfig

INSTRUMENTATION_NAME = "sfu_telemetry"


def build_resource(config: TelemetryConfig) -> Resource:
    attrs: dict[str, str] = {
        "service.name": config.service_name,
        "service.namespace": config.service_namespace,
        "service.version": config.service_version,
        "deployment.environment.name": config.environment,
        "sfu.data_class.max": config.data_class_max,
        "sfu.content_level": config.content_level,
    }
    if config.product:
        attrs["sfu.product"] = config.product
    if config.zone:
        attrs["sfu.zone"] = config.zone
    return Resource.create(attrs)


def build_tracer_provider(
    config: TelemetryConfig, extra_processors: list[SpanProcessor] | None = None
) -> TracerProvider:
    """Always returns an SDK provider so ids exist; exporters only when export != off."""
    provider = TracerProvider(resource=build_resource(config))
    if config.export == "otlp":
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter

        provider.add_span_processor(
            BatchSpanProcessor(
                OTLPSpanExporter(
                    endpoint=f"{config.otlp_endpoint.rstrip('/')}/v1/traces", timeout=5
                )
            )
        )
    elif config.export == "console":
        provider.add_span_processor(BatchSpanProcessor(ConsoleSpanExporter()))
    for p in extra_processors or []:
        provider.add_span_processor(p)
    return provider


def build_meter_provider(
    config: TelemetryConfig, extra_readers: list[MetricReader] | None = None
) -> MeterProvider:
    readers: list[MetricReader] = list(extra_readers or [])
    if config.export == "otlp":
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter

        readers.append(
            PeriodicExportingMetricReader(
                OTLPMetricExporter(
                    endpoint=f"{config.otlp_endpoint.rstrip('/')}/v1/metrics", timeout=5
                ),
                export_interval_millis=config.metric_export_interval_ms,
            )
        )
    elif config.export == "console":
        readers.append(
            PeriodicExportingMetricReader(
                ConsoleMetricExporter(), export_interval_millis=config.metric_export_interval_ms
            )
        )
    return MeterProvider(resource=build_resource(config), metric_readers=readers)


def tracer() -> trace.Tracer:
    return trace.get_tracer(INSTRUMENTATION_NAME)


def meter() -> metrics.Meter:
    return metrics.get_meter(INSTRUMENTATION_NAME)


def current_trace_id() -> str | None:
    """The active trace id as 32 lowercase hex characters, or None outside a span."""
    ctx = trace.get_current_span().get_span_context()
    return format(ctx.trace_id, "032x") if ctx.is_valid else None
