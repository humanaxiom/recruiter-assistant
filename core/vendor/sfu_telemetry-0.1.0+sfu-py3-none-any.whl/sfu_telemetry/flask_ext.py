"""Flask server instrumentation (same contract as :mod:`sfu_telemetry.asgi`)."""

from __future__ import annotations

import logging
import time
from collections.abc import Iterable
from typing import TYPE_CHECKING, Any

from opentelemetry import context, propagate, trace
from opentelemetry.trace import SpanKind, Status, StatusCode

from sfu_telemetry.tracing import meter, tracer

if TYPE_CHECKING:
    from flask import Flask
    from flask.wrappers import Response

access_log = logging.getLogger("sfu_telemetry.access")

_STATE_KEY = "_sfu_telemetry"


def instrument_flask(app: Flask, *, excluded_paths: Iterable[str] = ("/health",)) -> Flask:
    from flask import g, request

    excluded = frozenset(excluded_paths)
    duration = meter().create_histogram(
        "http.server.request.duration", unit="s", description="HTTP server request duration"
    )

    @app.before_request
    def _start() -> None:
        if request.path in excluded:
            return
        parent = propagate.extract({k.lower(): v for k, v in request.headers.items()})
        span = tracer().start_span(
            request.method,
            context=parent,
            kind=SpanKind.SERVER,
            attributes={"http.request.method": request.method},
        )
        token = context.attach(trace.set_span_in_context(span, parent))
        setattr(g, _STATE_KEY, (span, token, time.perf_counter(), 500))  # noqa: B010

    @app.after_request
    def _after(response: Response) -> Response:
        state = getattr(g, _STATE_KEY, None)
        if state is not None:
            span_ctx = state[0].get_span_context()
            if span_ctx.is_valid:
                response.headers.setdefault("X-Request-ID", format(span_ctx.trace_id, "032x"))
            setattr(g, _STATE_KEY, (*state[:3], response.status_code))  # noqa: B010
        return response

    @app.teardown_request
    def _end(exc: BaseException | None) -> None:
        state: Any = getattr(g, _STATE_KEY, None)
        if state is None:
            return
        span, token, start, status_code = state
        route = request.url_rule.rule if request.url_rule is not None else None
        if exc is not None:
            status_code = 500
            span.set_attribute("error.type", type(exc).__name__)
        if route:
            span.update_name(f"{request.method} {route}")
            span.set_attribute("http.route", route)
        span.set_attribute("http.response.status_code", status_code)
        if exc is not None or status_code >= 500:
            span.set_status(Status(StatusCode.ERROR, str(status_code)))
        elapsed = time.perf_counter() - start
        attrs: dict[str, str | int] = {
            "http.request.method": request.method,
            "http.response.status_code": status_code,
        }
        if route:
            attrs["http.route"] = route
        duration.record(elapsed, attrs)
        access_log.info("http.request", extra={**attrs, "duration_ms": round(elapsed * 1000, 1)})
        span.end()
        context.detach(token)

    return app
