"""LLM call spans.

One context manager for every OpenAI-compatible call (Ollama, vLLM, llama.cpp,
and any registered external provider). It writes both attribute dialects in
use at SFU so existing Phoenix views keep working while Grafana/Tempo use the
OpenTelemetry GenAI conventions:

=====================  ==================================  ===========================
concept                OTel GenAI                          OpenInference
=====================  ==================================  ===========================
operation              ``gen_ai.operation.name``           ``openinference.span.kind``
model                  ``gen_ai.request.model``            ``llm.model_name``
tokens                 ``gen_ai.usage.input_tokens`` ...   ``llm.token_count.*``
=====================  ==================================  ===========================

Plus ``sfu.*``: ``sfu.llm.pass``, ``sfu.prompt.hash``, ``sfu.prompt.version``,
``sfu.llm.attempts``. Prompt and response bodies are never recorded here.
"""

from __future__ import annotations

import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Literal

from opentelemetry import trace
from opentelemetry.trace import Span, SpanKind, Status, StatusCode

from sfu_telemetry.tracing import meter, tracer

Operation = Literal["chat", "embeddings", "text_completion"]

_OPENINFERENCE_KIND: dict[str, str] = {
    "chat": "LLM",
    "text_completion": "LLM",
    "embeddings": "EMBEDDING",
}


@dataclass
class LLMCall:
    """Handle yielded by :func:`llm_span` to record what came back."""

    span: Span
    operation: str
    model: str
    provider: str
    input_tokens: int | None = None
    output_tokens: int | None = None
    attempts: int = 0
    _attrs: dict[str, str] = field(default_factory=dict)

    def record_usage(self, input_tokens: int | None, output_tokens: int | None) -> None:
        if input_tokens is not None:
            self.input_tokens = int(input_tokens)
            self.span.set_attribute("gen_ai.usage.input_tokens", self.input_tokens)
            self.span.set_attribute("llm.token_count.prompt", self.input_tokens)
        if output_tokens is not None:
            self.output_tokens = int(output_tokens)
            self.span.set_attribute("gen_ai.usage.output_tokens", self.output_tokens)
            self.span.set_attribute("llm.token_count.completion", self.output_tokens)
        if self.input_tokens is not None and self.output_tokens is not None:
            self.span.set_attribute("llm.token_count.total", self.input_tokens + self.output_tokens)

    def record_response_model(self, model: str | None) -> None:
        if model:
            self.span.set_attribute("gen_ai.response.model", model)

    def record_attempt(self) -> None:
        self.attempts += 1
        self.span.set_attribute("sfu.llm.attempts", self.attempts)


def _metric_attrs(call: LLMCall, error_type: str | None) -> dict[str, str]:
    attrs = {
        "gen_ai.operation.name": call.operation,
        "gen_ai.request.model": call.model,
        "gen_ai.provider.name": call.provider,
        **call._attrs,
    }
    if error_type:
        attrs["error.type"] = error_type
    return attrs


@contextmanager
def llm_span(
    operation: Operation,
    *,
    model: str,
    provider: str,
    server_address: str | None = None,
    pass_name: str | None = None,
    prompt_hash: str | None = None,
    prompt_version: str | None = None,
) -> Iterator[LLMCall]:
    """Wrap one logical model call (including its retries) in a CLIENT span."""
    attrs: dict[str, str | int] = {
        "gen_ai.operation.name": operation,
        "gen_ai.request.model": model,
        "gen_ai.provider.name": provider,
        "openinference.span.kind": _OPENINFERENCE_KIND[operation],
        "llm.model_name": model,
    }
    metric_extra: dict[str, str] = {}
    if server_address:
        attrs["server.address"] = server_address
    if pass_name:
        attrs["sfu.llm.pass"] = pass_name
        metric_extra["sfu.llm.pass"] = pass_name
    if prompt_hash:
        attrs["sfu.prompt.hash"] = prompt_hash
    if prompt_version:
        attrs["sfu.prompt.version"] = prompt_version
    start = time.perf_counter()
    with tracer().start_as_current_span(
        f"{operation} {model}",
        kind=SpanKind.CLIENT,
        attributes=attrs,
        record_exception=False,
        set_status_on_exception=False,
    ) as span:
        call = LLMCall(span=span, operation=operation, model=model, provider=provider)
        call._attrs = metric_extra
        error_type: str | None = None
        try:
            yield call
        except BaseException as exc:
            error_type = type(exc).__name__
            span.set_attribute("error.type", error_type)
            # Type only: an exception message from a validator can embed the
            # offending model output, which may be candidate data.
            span.set_status(Status(StatusCode.ERROR, error_type))
            raise
        finally:
            _record_metrics(call, time.perf_counter() - start, error_type)


def _record_metrics(call: LLMCall, duration_s: float, error_type: str | None) -> None:
    m = meter()
    attrs = _metric_attrs(call, error_type)
    m.create_histogram(
        "gen_ai.client.operation.duration", unit="s", description="GenAI operation duration"
    ).record(duration_s, attrs)
    usage = m.create_histogram(
        "gen_ai.client.token.usage", unit="{token}", description="Tokens used per GenAI call"
    )
    if call.input_tokens is not None:
        usage.record(call.input_tokens, {**attrs, "gen_ai.token.type": "input"})
    if call.output_tokens is not None:
        usage.record(call.output_tokens, {**attrs, "gen_ai.token.type": "output"})


def current_span_is_recording() -> bool:
    return trace.get_current_span().is_recording()
