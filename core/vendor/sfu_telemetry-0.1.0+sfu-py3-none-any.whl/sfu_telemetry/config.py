"""Telemetry configuration.

Services build a :class:`TelemetryConfig` from their own settings object (the
recommended path for repos that centralise configuration) or call
:meth:`TelemetryConfig.from_env` to read the ``SFU_*`` / ``OTEL_*`` variables.

The config refuses unsafe combinations at construction time, mirroring the
"refuse to start" discipline the SFU products already use: content capture
(``debug``) is only allowed in ``dev`` and only for data classes P and I.
"""

from __future__ import annotations

import os
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal, cast, get_args

DataClass = Literal["P", "I", "S", "R"]
ContentLevel = Literal["minimal", "standard", "debug"]
ExportMode = Literal["off", "otlp", "console"]
LogFormat = Literal["json", "text"]

_DATA_CLASSES: tuple[str, ...] = get_args(DataClass)
_CONTENT_LEVELS: tuple[str, ...] = get_args(ContentLevel)
_EXPORT_MODES: tuple[str, ...] = get_args(ExportMode)
_LOG_FORMATS: tuple[str, ...] = get_args(LogFormat)


class TelemetryConfigError(ValueError):
    """Raised for a configuration the library refuses to run with."""


@dataclass(frozen=True)
class TelemetryConfig:
    """Everything :func:`sfu_telemetry.init` needs.

    ``export`` defaults to ``off``: a fresh checkout, a CI run or an airgapped
    deployment never opens a socket for telemetry. Spans are still created so
    that logs carry ``trace_id`` and responses carry ``X-Request-ID``.
    """

    service_name: str
    service_namespace: str = "sfu"
    service_version: str = "unknown"
    product: str = ""
    environment: str = "dev"
    zone: str = ""
    data_class_max: DataClass = "I"
    content_level: ContentLevel = "minimal"
    export: ExportMode = "off"
    otlp_endpoint: str = "http://127.0.0.1:4318"
    metric_export_interval_ms: int = 15_000
    log_format: LogFormat = "json"
    log_level: str = "INFO"
    replace_access_log: bool = True

    def __post_init__(self) -> None:
        if not self.service_name.strip():
            raise TelemetryConfigError("service_name must be set")
        _check("data_class_max", self.data_class_max, _DATA_CLASSES)
        _check("content_level", self.content_level, _CONTENT_LEVELS)
        _check("export", self.export, _EXPORT_MODES)
        _check("log_format", self.log_format, _LOG_FORMATS)
        if self.content_level == "debug":
            if self.environment != "dev":
                raise TelemetryConfigError(
                    "content_level=debug captures content and is refused outside "
                    f"environment=dev (got {self.environment!r})"
                )
            if self.data_class_max in ("S", "R"):
                raise TelemetryConfigError(
                    "content_level=debug is refused for data_class_max "
                    f"{self.data_class_max!r}: sensitive content never enters telemetry"
                )
        if self.export == "otlp" and not self.otlp_endpoint.strip():
            raise TelemetryConfigError("export=otlp needs otlp_endpoint")

    @property
    def captures_content(self) -> bool:
        return self.content_level == "debug"

    @classmethod
    def from_env(
        cls, service_name: str | None = None, environ: Mapping[str, str] | None = None
    ) -> TelemetryConfig:
        env = os.environ if environ is None else environ
        name = service_name or env.get("OTEL_SERVICE_NAME", "")
        return cls(
            service_name=name,
            service_namespace=env.get("SFU_SERVICE_NAMESPACE", "sfu"),
            service_version=env.get("SFU_SERVICE_VERSION", "unknown"),
            product=env.get("SFU_PRODUCT", ""),
            environment=env.get("SFU_ENVIRONMENT", "dev"),
            zone=env.get("SFU_ZONE", ""),
            data_class_max=cast(DataClass, env.get("SFU_DATA_CLASS_MAX", "I")),
            content_level=cast(ContentLevel, env.get("SFU_CONTENT_LEVEL", "minimal")),
            export=cast(ExportMode, env.get("SFU_TELEMETRY_EXPORT", "off")),
            otlp_endpoint=env.get("OTEL_EXPORTER_OTLP_ENDPOINT", "http://127.0.0.1:4318"),
            log_format=cast(LogFormat, env.get("SFU_LOG_FORMAT", "json")),
            log_level=env.get("SFU_LOG_LEVEL", "INFO"),
        )


def _check(field: str, value: str, allowed: tuple[str, ...]) -> None:
    if value not in allowed:
        raise TelemetryConfigError(f"{field}={value!r} is not one of {allowed}")
