"""JSON logging with trace correlation.

Fixes the failure mode found in most SFU repos: ``logging.getLogger(__name__)``
everywhere, no handler configured, so INFO is silently dropped and ``extra=``
fields are never rendered. One call to :func:`configure_logging` installs a
root handler on stdout that

* renders every record as one JSON object per line,
* keeps ``extra=`` fields under ``attrs``,
* adds the current ``trace_id`` / ``span_id``,
* derives a low-cardinality ``event.name`` from the message *template*
  (``"parse_job.missing job_id=%s"`` -> ``parse_job.missing``),
* never renders exception *messages* unless content capture is on (an
  exception message can carry the very value a validator rejected).

Call sites do not change.
"""

from __future__ import annotations

import json
import logging
import logging.config
import re
import sys
import traceback
import uuid
from collections.abc import Mapping
from datetime import UTC, datetime
from typing import Any

from opentelemetry import trace

from sfu_telemetry.config import TelemetryConfig

#: Attributes every LogRecord has; anything else on a record came from ``extra=``.
_STD_ATTRS = frozenset(
    vars(logging.LogRecord("x", logging.INFO, "x", 0, "x", None, None)).keys()
) | {"message", "asctime", "taskName"}

_EVENT_RE = re.compile(r"^([a-z][a-z0-9_]*(?:\.[a-z0-9_]+)+)\b")
#: String arguments that are identifiers, not content: UUIDs and long hex ids.
_ID_RE = re.compile(
    r"^(?:[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|[0-9a-f]{16,64})$",
    re.IGNORECASE,
)
REDACTED = "[redacted]"

#: Loggers that install their own handlers and must be routed through ours.
_FRAMEWORK_LOGGERS = ("uvicorn", "uvicorn.error", "arq", "werkzeug", "gunicorn.error")


def event_name(template: object) -> str | None:
    """Return the dotted event name a message template starts with, if any."""
    if not isinstance(template, str):
        return None
    m = _EVENT_RE.match(template)
    return m.group(1) if m else None


def _safe_arg(value: Any) -> Any:
    """Keep values that cannot carry free text; redact everything else."""
    if value is None or isinstance(value, bool | int | float):
        return value
    if isinstance(value, uuid.UUID):
        return value
    if isinstance(value, str) and _ID_RE.match(value):
        return value
    return REDACTED


def safe_message(record: logging.LogRecord) -> str:
    """``record.getMessage()`` with every free-text argument replaced by ``[redacted]``.

    Used for data classes S and R: a call like ``log.info("x user=%s", email)``
    renders as ``x user=[redacted]`` while ids, counts and flags survive. The
    message TEMPLATE is trusted (it is source code); its arguments are not.
    """
    msg = str(record.msg)
    if not record.args:
        return msg
    try:
        if isinstance(record.args, Mapping):
            return msg % {k: _safe_arg(v) for k, v in record.args.items()}
        return msg % tuple(_safe_arg(a) for a in record.args)
    except (TypeError, ValueError, KeyError):
        return msg


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, bool | int | float | str):
        return value
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, list | tuple | set | frozenset):
        return [_jsonable(v) for v in value]
    return str(value)


class JsonFormatter(logging.Formatter):
    """One JSON object per record. See module docstring for the field set."""

    def __init__(self, config: TelemetryConfig) -> None:
        super().__init__()
        self._service = config.service_name
        self._capture_content = config.captures_content
        self._redact_args = config.data_class_max in ("S", "R") and not config.captures_content

    def format(self, record: logging.LogRecord) -> str:
        out: dict[str, Any] = {
            "ts": datetime.fromtimestamp(record.created, tz=UTC)
            .isoformat(timespec="milliseconds")
            .replace("+00:00", "Z"),
            "severity": record.levelname,
            "logger": record.name,
            "service.name": self._service,
            "body": safe_message(record) if self._redact_args else record.getMessage(),
        }
        name = event_name(record.msg)
        if name:
            out["event.name"] = name
        ctx = trace.get_current_span().get_span_context()
        if ctx.is_valid:
            out["trace_id"] = format(ctx.trace_id, "032x")
            out["span_id"] = format(ctx.span_id, "016x")
        attrs = {k: _jsonable(v) for k, v in record.__dict__.items() if k not in _STD_ATTRS}
        if attrs:
            out["attrs"] = attrs
        if record.exc_info and record.exc_info[0] is not None:
            exc_type, exc, tb = record.exc_info
            out["exception.type"] = f"{exc_type.__module__}.{exc_type.__qualname__}"
            if self._capture_content:
                out["exception.message"] = str(exc)
                out["exception.stacktrace"] = "".join(traceback.format_exception(exc_type, exc, tb))
            else:
                # Frames only: file, line and function. Neither the exception's
                # message nor the frames' source lines are rendered, because
                # either can carry a value (an f-string, a literal) verbatim.
                out["exception.stacktrace"] = "\n".join(
                    f"{fs.filename}:{fs.lineno} in {fs.name}" for fs in traceback.extract_tb(tb)
                )
        return json.dumps(out, ensure_ascii=False, default=str)


class TextFormatter(logging.Formatter):
    """Human-readable fallback (``log_format=text``) that still carries trace ids."""

    def __init__(self) -> None:
        super().__init__("%(asctime)s %(levelname)s %(name)s %(message)s")

    def format(self, record: logging.LogRecord) -> str:
        line = super().format(record)
        ctx = trace.get_current_span().get_span_context()
        if ctx.is_valid:
            line += f" trace_id={ctx.trace_id:032x}"
        return line


def configure_logging(config: TelemetryConfig) -> None:
    """Install the stdout handler on the root logger and route framework loggers to it.

    ``disable_existing_loggers`` is False: module loggers created at import
    time keep working, and pytest's ``caplog`` still sees every record.
    """
    formatter = "sfu_json" if config.log_format == "json" else "sfu_text"
    framework: dict[str, Any] = {
        name: {"handlers": [], "propagate": True} for name in _FRAMEWORK_LOGGERS
    }
    if config.replace_access_log:
        # The ASGI middleware emits ``http.request`` with the route TEMPLATE and
        # no query string or client address; uvicorn's own access line carries
        # the raw path, so it is silenced rather than duplicated.
        framework["uvicorn.access"] = {"handlers": [], "propagate": False, "level": "WARNING"}
    else:
        framework["uvicorn.access"] = {"handlers": [], "propagate": True}
    logging.config.dictConfig(
        {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "sfu_json": {"()": JsonFormatter, "config": config},
                "sfu_text": {"()": TextFormatter},
            },
            "handlers": {
                "sfu_stdout": {
                    "class": "logging.StreamHandler",
                    "stream": sys.stdout,
                    "formatter": formatter,
                }
            },
            "root": {"level": config.log_level.upper(), "handlers": ["sfu_stdout"]},
            "loggers": framework,
        }
    )
