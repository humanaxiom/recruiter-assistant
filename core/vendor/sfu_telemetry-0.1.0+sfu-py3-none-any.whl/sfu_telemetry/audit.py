"""Canonical audit envelope (``stc-audit/1``) and its hash chain.

The envelope unifies the two audit vocabularies already in SFU products:

=========================  ================================  ===========================
envelope                   recruiter-assistant ``audit_log``  jd-assistant ``audit_log``
=========================  ================================  ===========================
``action``                 ``action``                         ``event_type``
``subject.type`` / ``.id``  ``subject_type`` / ``subject_id``  ``entity_type`` / ``entity_id``
``actor.kind``             ``actor_kind``                     (string actor -> user)
``occurred_at``            ``occurred_at``                    ``created_at``
=========================  ================================  ===========================

``row_hash = sha256(prev_hash || canonical_json(envelope_without_hashes))``,
per source, so each product's chain can be verified independently and
checkpointed centrally.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

SCHEMA_VERSION = "stc-audit/1"
GENESIS = "0" * 64

ActorKind = Literal["user", "service", "agent"]


@dataclass(frozen=True)
class Actor:
    kind: ActorKind
    pseudo_id: str | None = None
    role: str | None = None
    agent_run_id: str | None = None


@dataclass(frozen=True)
class Subject:
    type: str
    id: str | None = None


@dataclass(frozen=True)
class AuditEnvelope:
    event_id: str
    source: str
    source_seq: int
    occurred_at: str
    product: str
    service: str
    zone: str
    actor: Actor
    action: str
    subject: Subject
    data_class: str = "S"
    context: dict[str, Any] = field(default_factory=dict)
    details: dict[str, Any] = field(default_factory=dict)
    trace_id: str | None = None
    schema_version: str = SCHEMA_VERSION

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def canonical_json(obj: Any) -> bytes:
    """Deterministic JSON: sorted keys, no whitespace, UTF-8."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def chain_hash(prev_hash: str, envelope: dict[str, Any]) -> str:
    body = {k: v for k, v in envelope.items() if k not in ("prev_hash", "row_hash")}
    return hashlib.sha256(prev_hash.encode() + canonical_json(body)).hexdigest()


def verify_chain(rows: list[dict[str, Any]], start_prev: str = GENESIS) -> int | None:
    """Return the index of the first broken row, or None if the chain is intact."""
    prev = start_prev
    for i, row in enumerate(rows):
        if row.get("prev_hash") != prev or chain_hash(prev, row) != row.get("row_hash"):
            return i
        prev = str(row["row_hash"])
    return None


def pseudonymise(value: str, key: bytes) -> str:
    """Keyed, stable pseudonym (HMAC-SHA256, first 32 hex chars)."""
    import hmac

    return hmac.new(key, value.encode(), hashlib.sha256).hexdigest()[:32]
