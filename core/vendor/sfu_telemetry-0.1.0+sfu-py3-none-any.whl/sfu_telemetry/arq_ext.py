"""Trace propagation across an arq (Redis) job queue without changing task signatures.

arq passes only positional/keyword *task* arguments, and many repos pin their
task registry, so the carrier is a short-lived Redis key per job instead of a
task argument:

* enqueue side: :func:`instrument_arq_pool` wraps ``pool.enqueue_job`` so that
  when a span is active it writes ``sfu:traceparent:<job_id>`` (the traceparent
  plus the function name) before enqueueing;
* worker side: :func:`job_hooks` returns ``on_job_start`` / ``on_job_end``
  callables for ``WorkerSettings``. ``on_job_start`` runs in the same asyncio
  task that then creates the job's task, so the context it attaches is
  inherited by the job and every span/log inside it joins the request's trace.

Cron jobs (and jobs enqueued outside any span) start their own root trace,
unless their name is in ``skip_root`` (use it for high-frequency pollers).
"""

from __future__ import annotations

import json
import logging
import uuid
from collections.abc import Awaitable, Callable, Iterable
from typing import Any, Protocol

from opentelemetry import context, propagate, trace
from opentelemetry.trace import SpanKind

from sfu_telemetry.tracing import tracer

KEY_PREFIX = "sfu:traceparent:"
_CTX_SPAN = "_sfu_job_span"
_CTX_TOKEN = "_sfu_job_token"  # noqa: S105 - a ctx key, not a secret

log = logging.getLogger(__name__)


class _RedisLike(Protocol):
    async def get(self, name: str) -> Any: ...

    async def set(self, name: str, value: str, ex: int | None = None) -> Any: ...


JobHook = Callable[[dict[str, Any]], Awaitable[None]]


def _carrier() -> dict[str, str]:
    carrier: dict[str, str] = {}
    propagate.inject(carrier)
    return carrier


def instrument_arq_pool(pool: Any, *, ttl_s: int = 86_400) -> Any:
    """Wrap ``pool.enqueue_job`` in place; returns the same pool for chaining."""
    original = pool.enqueue_job
    if getattr(original, "_sfu_instrumented", False) is True:
        return pool

    async def enqueue_job(function: str, *args: Any, **kwargs: Any) -> Any:
        carrier = _carrier()
        if "traceparent" in carrier:
            # arq's own default id is uuid4().hex; minting it here keeps the same
            # semantics while letting the carrier be written BEFORE the job is
            # visible to a worker.
            job_id = kwargs.get("_job_id") or uuid.uuid4().hex
            kwargs["_job_id"] = job_id
            try:
                await pool.set(
                    f"{KEY_PREFIX}{job_id}",
                    json.dumps({"carrier": carrier, "fn": function}),
                    ex=ttl_s,
                )
            except Exception:  # tracing never blocks the work
                log.warning("sfu_telemetry.arq.carrier_write_failed", exc_info=True)
        return await original(function, *args, **kwargs)

    enqueue_job._sfu_instrumented = True  # type: ignore[attr-defined]
    setattr(pool, "enqueue_job", enqueue_job)  # noqa: B010
    return pool


def _cron_name(job_id: str) -> str | None:
    # arq cron ids look like ``cron:<function>:<unix_ms>``
    parts = job_id.split(":")
    return parts[1] if len(parts) >= 3 and parts[0] == "cron" else None


def job_hooks(
    *,
    redis_ctx_key: str = "redis",
    skip_root: Iterable[str] = (),
) -> tuple[JobHook, JobHook]:
    """Return ``(on_job_start, on_job_end)`` for an arq ``WorkerSettings``."""
    skip = frozenset(skip_root)

    async def on_job_start(ctx: dict[str, Any]) -> None:
        job_id = str(ctx.get("job_id", ""))
        name = _cron_name(job_id)
        parent: context.Context | None = None
        redis: _RedisLike | None = ctx.get(redis_ctx_key)
        if redis is not None and name is None:
            try:
                raw = await redis.get(f"{KEY_PREFIX}{job_id}")
            except Exception:
                log.warning("sfu_telemetry.arq.carrier_read_failed", exc_info=True)
                raw = None
            if raw:
                data = json.loads(raw)
                parent = propagate.extract(data.get("carrier", {}))
                name = data.get("fn")
        if parent is None and name in skip:
            return
        span = tracer().start_span(
            f"arq.job {name or 'unknown'}",
            context=parent,
            kind=SpanKind.CONSUMER,
            attributes={
                "messaging.system": "arq",
                "sfu.job.name": name or "unknown",
                "sfu.job.id": job_id,
                "sfu.job.try": int(ctx.get("job_try", 1)),
            },
        )
        ctx[_CTX_SPAN] = span
        ctx[_CTX_TOKEN] = context.attach(trace.set_span_in_context(span, parent))

    async def on_job_end(ctx: dict[str, Any]) -> None:
        span = ctx.pop(_CTX_SPAN, None)
        token = ctx.pop(_CTX_TOKEN, None)
        if span is not None:
            span.end()
        if token is not None:
            context.detach(token)

    return on_job_start, on_job_end
