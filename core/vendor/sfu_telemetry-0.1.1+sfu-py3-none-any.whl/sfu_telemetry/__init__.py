"""sfu-telemetry: SFU Telemetry Conventions (STC) for Python services.

Typical use, once per process::

    from sfu_telemetry import TelemetryConfig, init

    init(TelemetryConfig(service_name="recruiter-api", product="recruiter",
                         data_class_max="S", export="otlp",
                         otlp_endpoint="http://collector:4318"))
"""

from __future__ import annotations

import atexit
import threading

from opentelemetry import metrics, trace
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.trace import TracerProvider

from sfu_telemetry.config import TelemetryConfig, TelemetryConfigError
from sfu_telemetry.llm import LLMCall, llm_span
from sfu_telemetry.logs import configure_logging
from sfu_telemetry.tracing import (
    build_meter_provider,
    build_tracer_provider,
    current_trace_id,
)

__all__ = [
    "LLMCall",
    "Telemetry",
    "TelemetryConfig",
    "TelemetryConfigError",
    "current_trace_id",
    "init",
    "llm_span",
]

__version__ = "0.1.1+sfu"

_lock = threading.Lock()
_active: Telemetry | None = None


class Telemetry:
    def __init__(
        self,
        config: TelemetryConfig,
        tracer_provider: TracerProvider,
        meter_provider: MeterProvider,
    ) -> None:
        self.config = config
        self.tracer_provider = tracer_provider
        self.meter_provider = meter_provider

    def shutdown(self) -> None:
        self.tracer_provider.shutdown()
        self.meter_provider.shutdown(timeout_millis=5_000)


def init(config: TelemetryConfig) -> Telemetry:
    """Configure logging, tracing and metrics for this process. Idempotent.

    A second call returns the first ``Telemetry``; OpenTelemetry's global
    providers can only be set once per process.
    """
    global _active
    with _lock:
        if _active is not None:
            return _active
        configure_logging(config)
        tp = build_tracer_provider(config)
        mp = build_meter_provider(config)
        trace.set_tracer_provider(tp)
        metrics.set_meter_provider(mp)
        _active = Telemetry(config, tp, mp)
        atexit.register(_active.shutdown)
        return _active
